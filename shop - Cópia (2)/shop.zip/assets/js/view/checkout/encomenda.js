import get_template from '../../components/get_template.js'

export default {
    data: function () {
        return {
            title: "home",
            type: 'A',
            img: '',
            totalCat: 0,
            isActive2: true,
            qtddCart: 0,
            carinho: [],
            carinhoLista: [],
            dados_pesuais: false,
            id: '',
      
            usuario: '',
            email: '',
            produtos: [],
             
        } 
        
    },

    methods:{
        async finalizarpedido() {

            // Verifica se a propriedade no localStorage
            if (localStorage.hasOwnProperty("carinho")) {
              let carinho = JSON.parse(localStorage.getItem("carinho"));
      
              for (var i = 0; i < carinho.length; i++) {
                this.produtos[i] = carinho[i].id;
              }
      
              console.log(); //=> ['A', 'B', 'C']
      
      
              this.error = null;
      
              this.id = "22"
              this.usuario = "kimmm"
              this.email = "kimmm@gmail.com"
               
              this.produtos
      
      
              let res = await api.encomenda(this.id, this.usuario, this.email, this.produtos);
      
              if (res.error) {
                this.error = res.message;
                iziToast.error({
                  title: "Error",
                  message: this.error,
                  position: "bottomCenter",
                });
      
                return null;
              }
      
              this.msg = res.message;
              iziToast.success({
                title: "OK",
                message: this.msg,
                position: "bottomCenter",
              });
      
      
      
            } else {
              alert("Errroooooo")
            }
      
      
          },

    },

    async mounted() {

           
    },
    template: await get_template('./assets/js/view/checkout/encomenda')
}
 
export default {
    path: 'http://localhost:3333/api'
}